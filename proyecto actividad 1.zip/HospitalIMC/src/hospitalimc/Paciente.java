/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniel Trujillo 
 */
package hospitalimc;

public class Paciente {
    // Atributos tambien conocido como Encapsulamiento
    double peso;
    double estatura;

    // Constructor
    public Paciente(double peso, double estatura) {
        this.peso = peso;
        this.estatura = estatura;
    }

    // Método para calcular IMC
    public double calcularIMC() {
        // Fórmula: peso / (estatura * estatura) [cite: 5]
        return peso / (estatura * estatura);
    }

    // Método para obtener el nivel de peso
    public String obtenerDiagnostico() {
        double imc = calcularIMC();

        // Validaciones según la tabla que no da la actividad 1
        if (imc < 18.5) {
            return "Bajo peso";
        } else if (imc >= 18.5 && imc <= 24.9) {
            return "Peso normal";
        } else if (imc >= 25 && imc <= 29.9) {
            return "Sobrepeso";
        } else if (imc >= 30 && imc <= 34.9) {
            return "Obesidad grado I";
        } else if (imc >= 35 && imc <= 39.9) {
            return "Obesidad grado II";
        } else {
            return "Obesidad grado III"; // Para 40 o más
        }
    }
}