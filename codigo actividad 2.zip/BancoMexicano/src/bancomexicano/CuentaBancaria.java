/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author tgdg
 */
package bancomexicano;

public class CuentaBancaria {
    
    // ATRIBUTO (Static para que el saldo se mantenga entre ventanas)
    private static double saldo = 0;

    // MÉTODOS
    public void depositar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
        }
    }

    public void retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "Saldo insuficiente");
        }
    }

    public double getSaldo() {
        return saldo;
    }
}
